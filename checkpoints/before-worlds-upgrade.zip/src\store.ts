import { species } from "./data";
import { config } from "./config";
export const uid = () =>
  globalThis.crypto?.randomUUID?.() ||
  "demo-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
export type Consent = {
  id: string;
  participantId: string;
  version: string;
  timestamp: string;
  accepted: boolean;
  scope: string;
  withdrawnAt?: string;
};
export type Observation = {
  id: string;
  contributor: string;
  speciesId: number | null;
  provisional: string;
  observedAt: string;
  createdAt: string;
  location: string;
  uncertainty: number;
  coordinates?: { lat: number; lon: number };
  photo?: string;
  identification: string;
  review: string;
  reviewNotes: string;
  method: string;
  notes: string;
  taskId: string;
  siteId: string;
  consentId: string;
  sensitive: boolean;
  provenance: string;
  recordType: "HumanObservation";
  individuals: number;
  duration: number;
  habitat: string;
  activity: string;
  weather: string;
};
export type Task = {
  id: string;
  title: string;
  question: string;
  instructions: string;
  target: string;
  region: string;
  duration: number;
  status: string;
  reward: number;
  type: "Research" | "Exploration";
  requiredFields: string;
  safety: string;
};
export type Site = {
  id: string;
  name: string;
  location: string;
  uncertainty: number;
  habitat: string;
};
export type State = {
  consents: Consent[];
  observations: Observation[];
  xp: number;
  claimed: string[];
  ecosystem: number[];
  tasks: Task[];
  sites: Site[];
  mode: string;
};
export const initialTasks: Task[] = [
  {
    id: "tree",
    title: "Urban Tree Watch",
    question:
      "How do repeated observations document visible changes in urban tree conditions?",
    instructions:
      "Revisit the same tree. Photograph from a similar position. Record visible foliage and flowering, the date and observation effort.",
    target: "Trees",
    region: "Australian urban green spaces",
    duration: 5,
    status: "Published",
    reward: 40,
    type: "Research",
    requiredFields: "Date, site, duration, foliage notes",
    safety:
      "Observe from a safe public path. Do not enter private land or damage vegetation.",
  },
  {
    id: "birds",
    title: "Seasonal Bird Survey",
    question: "Which birds are observed during a consistent five-minute watch?",
    instructions:
      "Stay in one safe location for five minutes. Record an identified bird, number seen, habitat and effort. This prototype records positive sightings only.",
    target: "Birds",
    region: "Australia",
    duration: 5,
    status: "Published",
    reward: 30,
    type: "Research",
    requiredFields: "Date, site, duration, number observed",
    safety: "Keep your distance. Avoid nests and do not feed birds.",
  },
  {
    id: "spotter",
    title: "Bird Spotter",
    question: "Discover two different common birds.",
    instructions:
      "Save observations of two different bird species. Use the demo samples for the presentation.",
    target: "Birds",
    region: "Australia",
    duration: 0,
    status: "Published",
    reward: 30,
    type: "Exploration",
    requiredFields: "Two bird species",
    safety: "Keep a respectful distance from wildlife.",
  },
  {
    id: "leaf",
    title: "Leaf Explorer",
    question: "Discover two different plants.",
    instructions: "Observe plants without picking leaves or flowers.",
    target: "Plants",
    region: "Australia",
    duration: 0,
    status: "Published",
    reward: 30,
    type: "Exploration",
    requiredFields: "Two plant species",
    safety: "Stay on public paths.",
  },
];
export const emptyState = (): State => ({
  consents: [],
  observations: [],
  xp: 0,
  claimed: [],
  ecosystem: [],
  tasks: initialTasks.map((t) => ({ ...t })),
  sites: [],
  mode: "Fresh Explorer",
});
export const activeConsent = (s: State) => {
  const c = s.consents.at(-1);
  return c?.accepted && !c.withdrawnAt && c.version === config.consentVersion
    ? c
    : undefined;
};
export const makeConsent = (accepted: boolean): Consent => ({
  id: uid(),
  participantId: config.participantId,
  version: config.consentVersion,
  timestamp: new Date().toISOString(),
  accepted,
  scope:
    "Biodiversity photographs, identifications, dates, locations, and survey metadata for authorised biodiversity research; local prototype only.",
});
export function seedState(s: State): State {
  const consent = activeConsent(s);
  if (!consent) return s;
  const ids = [0, 2, 3, 0, 5];
  return {
    ...s,
    mode: "Demo Explorer",
    xp: 340,
    claimed: ["tree"],
    ecosystem: [0, 2, 3, 5],
    sites: [
      {
        id: "site-a",
        name: "Site A · Street tree",
        location: "Sydney · example neighbourhood",
        uncertainty: 1000,
        habitat: "Urban green space",
      },
    ],
    observations: ids.map((id, i) => ({
      id: "sample-" + (i + 1),
      contributor: config.participantId,
      speciesId: id,
      provisional: "",
      observedAt: `2026-${i < 2 ? "09" : "10"}-${String(10 + i).padStart(2, "0")}T09:30`,
      createdAt: new Date().toISOString(),
      location: "Sydney · example neighbourhood",
      uncertainty: 1000,
      identification: "User-confirmed demo identification",
      review: i === 0 ? "Demo reviewed" : "Awaiting review",
      reviewNotes: "",
      method: "Visual observation",
      notes: "Seeded example observation; no real field event.",
      taskId: i === 4 ? "tree" : "",
      siteId: "site-a",
      consentId: consent.id,
      sensitive: false,
      provenance: "Seeded demonstration",
      recordType: "HumanObservation",
      individuals: 1,
      duration: 5,
      habitat: "Urban green space",
      activity: "Observed",
      weather: "Not recorded",
    })),
  };
}
export const repository = {
  load(): State {
    try {
      const s = JSON.parse(localStorage.getItem(config.storageKey) || "null");
      return s && Array.isArray(s.consents) && Array.isArray(s.observations)
        ? s
        : emptyState();
    } catch {
      return emptyState();
    }
  },
  save(s: State) {
    localStorage.setItem(config.storageKey, JSON.stringify(s));
  },
};
export function speciesIds(s: State) {
  return [
    ...new Set(
      s.observations.flatMap((o) =>
        o.speciesId === null ? [] : [o.speciesId],
      ),
    ),
  ];
}
export function taskProgress(t: Task, s: State) {
  if (t.id === "spotter")
    return (
      Math.min(
        2,
        speciesIds(s).filter((id) => species[id].category === "Birds").length,
      ) / 2
    );
  if (t.id === "leaf")
    return (
      Math.min(
        2,
        speciesIds(s).filter((id) => species[id].category === "Plants").length,
      ) / 2
    );
  return s.observations.some((o) => o.taskId === t.id) ? 1 : 0;
}
export function exportRows(rows: Observation[]) {
  return rows.map((o) => ({
    occurrenceID: o.id,
    eventDate: o.observedAt,
    scientificName: o.speciesId === null ? "" : species[o.speciesId].latin,
    vernacularName:
      o.speciesId === null ? o.provisional : species[o.speciesId].name,
    locality: o.sensitive ? "Restricted" : o.location,
    coordinateUncertaintyInMeters: o.sensitive ? "" : o.uncertainty,
    samplingProtocol: o.method,
    basisOfRecord: o.recordType,
    individualCount: o.individuals,
    samplingEffort: o.duration,
    identificationVerificationStatus: o.identification,
    reviewStatus: o.review,
    taskId: o.taskId,
    consentRecordId: o.consentId,
    provenance: o.provenance,
  }));
}
export function csvText(rows: Observation[]) {
  const records = exportRows(rows);
  if (!records.length) return "";
  const keys = Object.keys(records[0]);
  const esc = (v: unknown) => {
    const text = String(v ?? "");
    const prefix = /^[=+\-@\t\r]/.test(text) ? "'" : "";
    return '"' + prefix + text.replace(/"/g, '""') + '"';
  };
  return [
    keys.map(esc).join(","),
    ...records.map((r) =>
      keys.map((k) => esc(r[k as keyof typeof r])).join(","),
    ),
  ].join("\r\n");
}
